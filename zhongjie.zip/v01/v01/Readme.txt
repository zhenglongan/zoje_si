-------- PROJECT GENERATOR --------
PROJECT NAME :	v01
PROJECT DIRECTORY :	E:\work\zhongjie\2843\v01\v01
CPU SERIES :	M16C/60
CPU GROUP :	62P(ROM384K)
TOOLCHAIN NAME :	Renesas M16C Standard Toolchain
TOOLCHAIN VERSION :	5.40.00
GENERATION FILES :
    E:\work\zhongjie\2843\v01\v01\v01.c
        main program file.
START UP FILES :
    E:\work\zhongjie\2843\v01\v01\ncrt0.a30
    E:\work\zhongjie\2843\v01\v01\sect30.inc

DATE & TIME : 2016/3/13 10:31:42
